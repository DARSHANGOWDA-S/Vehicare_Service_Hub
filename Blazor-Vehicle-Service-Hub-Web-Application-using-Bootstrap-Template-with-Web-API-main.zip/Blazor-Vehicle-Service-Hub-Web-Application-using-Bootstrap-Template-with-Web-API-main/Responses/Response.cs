﻿namespace BlazorServer.CarService.Shared.Responses
{
    public class Response
    {
        public string Message { get; set; } = string.Empty;
        public bool Success { get; set; } = true;
    }
}
