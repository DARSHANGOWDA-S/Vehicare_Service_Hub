﻿

namespace BlazorServer.CarService.Shared.ViewModels;

public class AddServiceViewModel
{
    public string? Name { get; set; }
}
